luajava.loadLib("org.keplerproject.luajava.test.LoadLibExample", "open")

eg.example(3)
